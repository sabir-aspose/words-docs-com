---
name: aspose.words
description: "Develop applications with Aspose.Words for .NET APIs to create, edit, convert, and render Word documents. Automate document comparison, reporting with LINQ Reporting Engine, mail merge, text search and replacement, document merging and splitting, digital signatures, watermark management, and AI-powered tasks such as translation, summarization, and grammar checking. Use this documentation when building, integrating, or troubleshooting document processing solutions."
---

# Aspose.Words for .NET Skill

This skill provides AI assistants with structured guidance for working with the Aspose.Words for .NET API, including documentation, code examples, and implementation best practices.

Load this skill whenever a request involves Aspose.Words APIs, document processing operations, or Word document automation.

## When to Use This Skill

Use this skill when you want to:

- automate document creation, editing, and conversion
- convert documents between supported file formats
- compare document content and identify differences
- generate documents using LINQ Reporting Engine or Mail Merge
- combine multiple documents or split a document into separate files
- add or remove watermarks and apply digital signatures
- leverage AI features such as translation, summarization, or grammar checking
- find information about supported file formats and API capabilities
- integrate Aspose.Words for .NET into your applications
- troubleshoot API usage or document processing behavior

## Example User Requests

- Convert DOCX to PDF with Aspose.Words for .NET
- Compare two Word documents
- Generate invoices using the LINQ Reporting Engine
- Perform a Mail Merge with data from a JSON or database source
- Replace text or insert content into a Word document
- Merge multiple DOCX files into a single document
- Split a document into separate files by section or page
- Add a watermark to a document
- Apply a digital signature to a document
- Translate a document using the Aspose.Words AI
- Summarize a document using the Aspose.Words AI
- Check grammar in a document using the Aspose.Words AI
- Which document formats can Aspose.Words for .NET read, write, and convert?

## Installation

Install Aspose.Words for .NET via NuGet:

```csharp
dotnet add package Aspose.Words
```

Or install Aspose.Words for .NET using Installer:

1. Download Aspose.Words_{LatestVersion}.msi from the [Download](https://releases.aspose.com/words/net/)
2. Run the installer and follow the on-screen instructions
3. Open your project in Visual Studio and add a reference to the installed Aspose.Words assembly

## Licensing

You can apply a license using a file or stream object.

How to apply a license from a file:

```csharp
License license = new License();

try
{
    license.SetLicense("Aspose.Words.lic");
    Console.WriteLine("License set successfully.");
}
catch (Exception e)
{
    Console.WriteLine("\nThere was an error setting the license: " + e.Message);
}
```

How to apply a license from a stream:

```csharp
License license = new License();

try
{
    license.SetLicense("Aspose.Words.lic");
    Console.WriteLine("License set successfully.");
}
catch (Exception e)
{
    Console.WriteLine("\nThere was an error setting the license: " + e.Message);
}
```

## Namespaces

Use the correct namespace depending on the feature:

`using Aspose.Words` – Core classes for creating, loading, editing, and saving Word documents
`using Aspose.Words.AI` – AI-powered document processing, including translation, summarization, and grammar checking
`using Aspose.Words.Bibliography` – Bibliography sources and citations
`using Aspose.Words.BuildingBlocks` – Building blocks such as AutoText and glossary documents
`using Aspose.Words.Comparing` – Document comparison and revision detection
`using Aspose.Words.DigitalSignatures` – Digital signatures for Word documents.
`using Aspose.Words.Drawing` – Shapes, images, SmartArt, and drawing objects.
`using Aspose.Words.Drawing.Charts` – Charts and chart elements.
`using Aspose.Words.Drawing.Ole` – OLE objects and embedded documents.
`using Aspose.Words.Fields` – Microsoft Word fields and field updates.
`using Aspose.Words.Fonts` – Font settings, sources, and substitution.
`using Aspose.Words.Framesets` – HTML framesets and frame pages.
`using Aspose.Words.Layout` – Document layout and page rendering information.
`using Aspose.Words.Lists` – Numbered and bulleted lists.
`using Aspose.Words.Loading` – Document loading options and callbacks.
`using Aspose.Words.LowCode` – Low-code document processing APIs.
`using Aspose.Words.MailMerging` – Mail Merge and reporting data sources.
`using Aspose.Words.Markup` – Structured document tags, custom XML, and revisions.
`using Aspose.Words.Math` – Office Math equations and mathematical objects.
`using Aspose.Words.Notes` – Footnotes, endnotes, and comments.
`using Aspose.Words.Properties` – Built-in and custom document properties.
`using Aspose.Words.Rendering` – Rendering documents to images and printing.
`using Aspose.Words.Replacing` – Find-and-replace operations and callbacks.
`using Aspose.Words.Reporting` – LINQ Reporting Engine for template-based document generation.
`using Aspose.Words.Saving` – Save options and export settings.
`using Aspose.Words.Settings` – Document compatibility and view settings.
`using Aspose.Words.Shaping` – Text shaping and OpenType font features.
`using Aspose.Words.Tables` – Tables, rows, and cells.
`using Aspose.Words.Themes` – Document themes and theme fonts.
`using Aspose.Words.Vba` – VBA projects and macros.
`using Aspose.Words.WebExtensions` – Office web extensions and task panes.

Include `using Aspose.Words;` only when accessing common functionality such as settings, licensing, exceptions, warnings, callbacks, or hyphenation.

## Quick Reference

### Create or Load a Document

Create a document from scratch:

```csharp
Document doc = new Document();

DocumentBuilder builder = new DocumentBuilder(doc);
builder.Writeln("Hello World!");

doc.Save("CreateNewDocument.docx");
```

Load a document:

```csharp
Document doc = new Document(MyDir + "Document.docx");
```

### Save a Document

Load DOC and save it to DOCX to a file:

```csharp
Document doc = new Document(MyDir + "Document.doc");

doc.Save("DocToDocx.docx");
```

### Document Conversion

Convert documents between supported formats:

```csharp
Document doc = new Document(MyDir + "Document.docx");
doc.Save("DocToDocx.pdf");
```
### Compare Documents

Check if two documents are equal or not:

```csharp
Document docA = new Document("Document1.docx");
Document docB = new Document("Document2.docx");
            
docA.Compare(docB, "user", DateTime.Now);

Console.WriteLine(docA.Revisions.Count == 0 ? "Documents are equal" : "Documents are not equal");
```

### LINQ Reporting

To build a report from the template, you can use the following source code:

```csharp
string dataDir = RunExamples.GetDataDir_LINQ();

string fileName = "HelloWorld.doc";
// Load the template document.
Document doc = new Document(dataDir + fileName);

// Create an instance of sender class to set it's properties.
Sender sender = new Sender { Name = "LINQ Reporting Engine", Message = "Hello World" };
            
// Create a Reporting Engine.
ReportingEngine engine = new ReportingEngine();
            
// Execute the build report.
engine.BuildReport(doc, sender, "sender");

dataDir = dataDir + RunExamples.GetOutputFilePath(fileName);

// Save the finished document to disk.
doc.Save(dataDir);
```

### Mail Merge

Execute a simple Mail Merge operation:

```csharp
Document doc = new Document();
DocumentBuilder builder = new DocumentBuilder(doc);

// Create Merge Fields.
builder.InsertField(" MERGEFIELD CustomerName ");
builder.InsertParagraph();
builder.InsertField(" MERGEFIELD Item ");
builder.InsertParagraph();
builder.InsertField(" MERGEFIELD Quantity ");

// Fill the fields in the document with user data.
doc.MailMerge.Execute(new string[] { "CustomerName", "Item", "Quantity" },
    new object[] { "John Doe", "Hawaiian", "2" });

doc.Save("SimpleMailMerge.docx");
```

### Search and Replace

Find the string “CustomerName” and replace it with the string “James Bond”:

```csharp
Document doc = new Document();
DocumentBuilder builder = new DocumentBuilder(doc);
            
builder.Writeln("Hello _CustomerName_,");

doc.Range.Replace("_CustomerName_", "James Bond", new FindReplaceOptions(FindReplaceDirection.Forward));

doc.Save("FindAndReplace.ReplaceWithString.docx");
```

### Insert and Append Documents

Merge documents, for example, append a document to the end of another document:

```csharp
Document dstDoc = new Document();
dstDoc.FirstSection.Body.AppendParagraph("Destination document text. ");

Document srcDoc = new Document();
srcDoc.FirstSection.Body.AppendParagraph("Source document text. ");

dstDoc.AppendDocument(srcDoc, ImportFormatMode.KeepSourceFormatting);

dstDoc.Save("JoinAndAppendDocuments.KeepSourceFormatting.docx");
```

### Split Large Documents

Split a document into smaller parts by heading:

```csharp
Document doc = new Document("Rendering.docx");

HtmlSaveOptions options = new HtmlSaveOptions
{
    DocumentSplitCriteria = DocumentSplitCriteria.HeadingParagraph
};
            
doc.Save("SplitDocument.ByHeadings.epub", options);
```

### Digital Signature

Sign documents using a certificate holder and sign options:

```csharp
CertificateHolder certHolder = CertificateHolder.Create("morzal.pfx", "aw");
            
DigitalSignatureUtil.Sign("Digitally signed.docx", "Document.Signed.docx", certHolder);
```

### Add Watermark

Add a text watermark:

```csharp
Document doc = new Document("Document.docx");

TextWatermarkOptions options = new TextWatermarkOptions()
{
    FontFamily = "Arial",
    FontSize = 36,
    Color = Color.Black,
    Layout = WatermarkLayout.Horizontal,
    IsSemitrasparent = false
};

doc.Watermark.SetText("Test", options);

doc.Save("WorkWithWatermark.AddTextWatermark.docx");
```

Add an image watermark:

```csharp
Document doc = new Document("Document.docx");

ImageWatermarkOptions options = new ImageWatermarkOptions
{
    Scale = 5,
    IsWashout = false
};

doc.Watermark.SetImage(Image.FromFile("Transparent background logo.png"), options);

doc.Save("WorkWithWatermark.AddImageWatermark.docx");
```

### AI-powered Features

Use AI-powered capabilities (if enabled) to translate or summarize documents, or to check grammar:

```csharp
AiModel model = ((OpenAiModel)AiModel.Create(AiModelType.Gpt4OMini).WithApiKey(apiKey)).WithOrganization("Organization").WithProject("Project");
```

### Document Protection

Encrypt a document with a password:

```csharp
Document doc = new Document();
DocumentBuilder builder = new DocumentBuilder(doc);
            
builder.Write("Hello world!");

DocSaveOptions saveOptions = new DocSaveOptions { Password = "password" };

doc.Save("WorkingWithDocSaveOptions.EncryptDocumentWithPassword.docx", saveOptions);
```

### Print a Document

Print a document using the XpsPrintHelper class:

```csharp
string dataDir = RunExamples.GetDataDir_RenderingAndPrinting();
// Open a sample document in Aspose.Words.
Document document = new Document("TestFile.doc");

// Specify the name of the printer you want to print to.
const string printerName = @"\\COMPANY\Brother MFC-885CW Printer";

// Print the document.
XpsPrintHelper.Print(document, printerName, "My Test Job", true);
```

## Reference Files

This skill includes comprehensive documentation in `references/`:

- **supported-formats.md** – supported document formats
- **licensing.md** – license types and license applying options
- **getting-started.md** – guides and tutorials for beginners
- **configuring.md** - configuring fonts, hyphenation, text shaping
- **create-or-load.md** – creating or loading a document
- **saving.md** – saving a document
- **conversion.md** – converting a document from one format to another
- **comparison.md** – comparison documents to detected changes: insertions, deletions, and modifications
- **reporting.md** – LINQ reporting engine
- **mail-merge.md** – creating personalized documents through a combination of a document template with data
- **replacement.md** – search and replace functionality
- **merge.md** – merging multiple documents into one
- **splitting.md** – splitting a large document by various split criteria
- **signature.md** – digital signing of documents
- **watermark.md** – adding or removing watermarks in documents
- **ai.md** – summarization, grammar checking, and document translation using AI models
- **protection.md** – document protection
- **printing.md** – document printing

Open the relevant reference file when detailed documentation is needed.

## Resources

- Official Aspose.Words for .NET documentation: https://docs.aspose.com/words/net/
- API Reference: https://reference.aspose.com/words/net

Official Aspose.Words for .NET documentation pages are AI-friendly and support the .md format. For example, the page `https://docs.aspose.com/words/net/convert-a-document-to-pdf/` has a version `https://docs.aspose.com/words/net/convert-a-document-to-pdf.md`, the page `https://docs.aspose.com/words/net/split-a-document/` has a version `https://docs.aspose.com/words/net/split-a-document.md`, and so on.

## Notes for AI Agents

- Prefer examples that use the official Aspose.Words for .NET APIs.
- Provide short and clear code snippets when possible.
- Use the references directory to retrieve detailed documentation.
- If a feature is not covered in this file, check the corresponding reference file.
- Always include the correct namespace for the feature being used (e.g., Aspose.Words.Rendering, Aspose.Words.Comparing).
- Always use the namespace specified in the feature documentation file.
- Do not rely on `using Aspose.Words;` namespace alone when feature-specific APIs are required.