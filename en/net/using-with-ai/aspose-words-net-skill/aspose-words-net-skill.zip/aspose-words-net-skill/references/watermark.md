# Aspose.Words for .NET - Add Watermark

---

**URL:** https://docs.aspose.com/words/net/working-with-watermark.md

**Contents:**
- Adding an Image Watermark
- Adding a Text Watermark
- Remove Watermark from a Document

---
title: "Add Watermark"
---

A watermark is a background image that displays behind the text in a document. A watermark can contain a text or an image represented by the [Watermark](https://reference.aspose.com/words/net/aspose.words/watermark/) class.

**Add a Watermark to a Document**

Aspose.Words provides the [WatermarkType](https://reference.aspose.com/words/net/aspose.words/watermark/type/)enumeration defining three possible types of watermarks (Text, Image, and None) to work with. 

**Insert a text watermark** in a document by defining [TextWatermarkOptions](https://reference.aspose.com/words/net/aspose.words/textwatermarkoptions/) using the [SetText](https://reference.aspose.com/words/net/aspose.words/watermark/settext/#settext) method:

```csharp
Document doc = new Document("Document.docx");

TextWatermarkOptions options = new TextWatermarkOptions()
{
    FontFamily = "Arial",
    FontSize = 36,
    Color = Color.Black,
    Layout = WatermarkLayout.Horizontal,
    IsSemitrasparent = false
};

doc.Watermark.SetText("Test", options);

doc.Save("WorkWithWatermark.AddTextWatermark.docx");
```

**Insert an image watermark** in a document by defining [ImageWatermarkOptions](https://reference.aspose.com/words/net/aspose.words/imagewatermarkoptions/) using the [SetImage](https://reference.aspose.com/words/net/aspose.words/watermark/setimage/#setimage) method:

```csharp
Document doc = new Document("Document.docx");

ImageWatermarkOptions options = new ImageWatermarkOptions
{
    Scale = 5,
    IsWashout = false
};

doc.Watermark.SetImage(Image.FromFile(ImagesDir + "Transparent background logo.png"), options);

doc.Save("WorkWithWatermark.AddImageWatermark.docx");
```

Image watermark can be inserted as image, string, or stream.

The watermark can also be inserted using shape class as well. It is very easy to insert any shape or image into a header or footer and thus create a watermark of any imaginable type.

**Remove Watermark from a Document**

The [Watermark](https://reference.aspose.com/words/net/aspose.words/watermark/) class provides the remove method to remove the watermark from a document.

```csharp
Document doc = new Document();

// Add a plain text watermark.
doc.Watermark.SetText("Aspose Watermark");

// If we wish to edit the text formatting using it as a watermark,
// we can do so by passing a TextWatermarkOptions object when creating the watermark.
TextWatermarkOptions textWatermarkOptions = new TextWatermarkOptions();
textWatermarkOptions.FontFamily = "Arial";
textWatermarkOptions.FontSize = 36;
textWatermarkOptions.Color = Color.Black;
textWatermarkOptions.Layout = WatermarkLayout.Diagonal;
textWatermarkOptions.IsSemitrasparent = false;

doc.Watermark.SetText("Aspose Watermark", textWatermarkOptions);

doc.Save("Document.TextWatermark.docx");

// We can remove a watermark from a document like this.
if (doc.Watermark.Type == WatermarkType.Text)
    doc.Watermark.Remove();

doc.Save("WorkWithWatermark.RemoveDocumentWatermark.docx");
```

---