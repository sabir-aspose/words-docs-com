# Aspose.Words for .NET - Sign with Digital Signature

---

**URL:** https://docs.aspose.com/words/net/working-with-digital-signatures.md

**Contents:**
- Supported Formats
- Create a Digital Signature
- Sign a Document
- Add a Signature Line
- Sign a Generated PDF Document
- Remove a Digital Signature

---
title: "Sign with Digital Signature"
---

A digital signature is a technological implementation of electronic signatures to sign documents and authenticate the signer to guarantee that a document has not been modified since it was signed. Use the [DigitalSignatureUtil](https://reference.aspose.com/words/net/aspose.words.digitalsignatures/digitalsignatureutil/) class to work with digital signatures.

**Supported Formats**

Aspose.Words allows you to work with digital signatures on DOC, OOXML, and ODT documents and to sign the generated document in PDF or XPS format.

**Create a Digital Signature**

Aspose.Words allows you to create X.509 certificate, a digital certificate that uses the internationally accepted X.509 PKI standard to verify that a public key belongs to the signer included inside the certificate. To do this, use the [Create](https://reference.aspose.com/words/net/aspose.words.digitalsignatures/certificateholder/create/) method within the [CertificateHolder](https://reference.aspose.com/words/net/aspose.words.digitalsignatures/certificateholder/) class.

**Sign a Document**

Aspose.Words allows you to sign a DOC, DOCX, XPS, or ODT document digitally using the [Sign](https://reference.aspose.com/words/net/aspose.words.digitalsignatures/digitalsignatureutil/sign/#sign/) method and [SignOptions](https://reference.aspose.com/words/net/aspose.words.digitalsignatures/signoptions/) properties.

```csharp
CertificateHolder certHolder = CertificateHolder.Create("morzal.pfx", "aw");
            
DigitalSignatureUtil.Sign("Digitally signed.docx", "Document.Signed.docx",
    certHolder);
```

**Add a Signature Line**

Aspose.Words allows you to insert a signature line using the [DocumentBuilder.InsertSignatureLine](https://reference.aspose.com/words/net/aspose.words/documentbuilder/insertsignatureline/) method.  You can also set the parameters for this representation using the [SignatureLineOptions](https://reference.aspose.com/words/net/aspose.words/signaturelineoptions/) class.

```csharp
Document doc = new Document();
DocumentBuilder builder = new DocumentBuilder(doc);

SignatureLineOptions signatureLineOptions = new SignatureLineOptions
{
    Signer = "yourname",
    SignerTitle = "Worker",
    Email = "yourname@aspose.com",
    ShowDate = true,
    DefaultInstructions = false,
    Instructions = "Please sign here.",
    AllowComments = true
};

SignatureLine signatureLine = builder.InsertSignatureLine(signatureLineOptions).SignatureLine;
signatureLine.ProviderId = Guid.Parse("CF5A7BB4-8F3C-4756-9DF6-BEF7F13259A2");
            
doc.Save("SignDocuments.SignatureLineProviderId.docx");

SignOptions signOptions = new SignOptions
{
    SignatureLineId = signatureLine.Id,
    ProviderId = signatureLine.ProviderId,
    Comments = "Document was signed by Aspose",
    SignTime = DateTime.Now
};

CertificateHolder certHolder = CertificateHolder.Create("morzal.pfx", "aw");

DigitalSignatureUtil.Sign("SignDocuments.SignatureLineProviderId.docx", 
    "SignDocuments.CreateNewSignatureLineAndSetProviderId.docx", certHolder, signOptions);
```

**Sign a Generated PDF Document**

Aspose.Words allows you to sign and get all details of a PDF document using the [PdfDigitalSignatureDetails](https://reference.aspose.com/words/net/aspose.words.saving/pdfdigitalsignaturedetails/) properties.

```csharp
Document doc = new Document();
DocumentBuilder builder = new DocumentBuilder(doc);
            
builder.Writeln("Test Signed PDF.");

PdfSaveOptions saveOptions = new PdfSaveOptions
{
    DigitalSignatureDetails = new PdfDigitalSignatureDetails(
        CertificateHolder.Create("morzal.pfx", "aw"), "reason", "location",
        DateTime.Now)
};

doc.Save("WorkingWithPdfSaveOptions.DigitallySignedPdfUsingCertificateHolder.pdf", saveOptions);
```

**Remove Digital Signatures**

Aspose.Words allows you to remove all digital signatures from a signed document using the [RemoveAllSignatures](https://reference.aspose.com/words/net/aspose.words.digitalsignatures/digitalsignatureutil/removeallsignatures/#removeallsignatures/) method.

```csharp
DigitalSignatureUtil.RemoveAllSignatures("Digitally signed.docx",
    "DigitalSignatureUtil.LoadAndRemove.FromString.docx");

// 2 - Determine the locations of both the signed document and the unsigned copy by file streams:
using (Stream streamIn = new FileStream("Digitally signed.docx", FileMode.Open))
{
    using (Stream streamOut = new FileStream("DigitalSignatureUtil.LoadAndRemove.FromStream.docx", FileMode.Create))
    {
        DigitalSignatureUtil.RemoveAllSignatures(streamIn, streamOut);
    }
}

// Verify that both our output documents have no digital signatures.
Assert.That(DigitalSignatureUtil.LoadSignatures("DigitalSignatureUtil.LoadAndRemove.FromString.docx"), Is.Empty);
Assert.That(DigitalSignatureUtil.LoadSignatures("DigitalSignatureUtil.LoadAndRemove.FromStream.docx"), Is.Empty);
```

You can not remove only one digital signature within your document.

---