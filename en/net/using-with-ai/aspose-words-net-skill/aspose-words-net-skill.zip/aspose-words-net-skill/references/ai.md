# Aspose.Words for .NET - Use AI-powered Features

---

**URL:** https://docs.aspose.com/words/net/ai-powered-features.md

**Contents:**
- Configure AI models
- Translate Document Using AI
- Summarize Document Using AI
- Check Grammar Using AI

---
title: "Use AI-powered Features"
---

Aspose.Words for .NET AI enables operations such as text summarization, grammar checking, and document translation using cutting edge models from Anthropic, Google, and OpenAI.

**Configure AI models**

The Aspose.Words for .NET can be connected to Anthropic, Google, and OpenAI models. To do this, just use the appropriate AiModel class and specify the [AiModelType](https://reference.aspose.com/words/net/aspose.words.ai/aimodeltype/).

```csharp
public static AiModel Create(AiModelType modelType)
```

In addition to the standard models, you can use an LLM deployed on your server. Just select the appropriate AiModel class and specify the URL, name, and ApiKey.

```csharp
public void SelfHostedModel()
{
    Document doc = new Document("Big document.docx");

    string apiKey = Environment.GetEnvironmentVariable("API_KEY");
    // Use OpenAI generative language models.
    AiModel model = new CustomAiModel().WithApiKey(apiKey);

    Document translatedDoc = model.Translate(doc, Language.Russian);
    translatedDoc.Save("AI.SelfHostedModel.docx");
}

// Custom self-hosted AI model.
internal class CustomAiModel : OpenAiModel
{
    protected override string Url
    {
        get { return "https://localhost/"; }
    }

    protected override string Name
    {
        get { return "my-model-24b"; }
    }
}
```

**Translate Document Using AI**

Translating documents supports multiple languages and formats, making it easy to work with a wide range of content.

To translate a document, use one of the [Translate](https://reference.aspose.com/words/net/aspose.words.ai/aimodel/translate/) methods and one of the supported languages listed in the [Language](https://reference.aspose.com/words/net/aspose.words.ai/language/) enumeration:

```csharp
Document doc = new Document("Document.docx");

string apiKey = Environment.GetEnvironmentVariable("API_KEY");
// Use Google generative language models.
AiModel model = AiModel.Create(AiModelType.Gemini15Flash).WithApiKey(apiKey);

Document translatedDoc = model.Translate(doc, Language.Arabic);
translatedDoc.Save("AI.AiTranslate.docx");
```

**Summarize Document Using AI**

To summarize a document, use one of the [Summarize](https://reference.aspose.com/words/net/aspose.words.ai/aimodel/summarize/) methods

You can also optionally specify [SummarizeOptions](https://reference.aspose.com/words/net/aspose.words.ai/summarizeoptions/). Use the following values from the [SummaryLength](https://reference.aspose.com/words/net/aspose.words.ai/summarylength/) enumeration to set the summary length:

* `VeryShort` - generates 1-2 sentences
* `Short` - generates 3-4 sentences
* `Medium` - generates 5-6 sentences
* `Long` - generates 7-10 sentences
* `VeryLong` - generates 11-20 sentences

Pass one or more documents to the Summarizer to produce a concise summary that accurately represents the content:

```csharp
Document firstDoc = new Document("Big document.docx");
Document secondDoc = new Document("Document.docx");

string apiKey = Environment.GetEnvironmentVariable("API_KEY");
// Use OpenAI or Google generative language models.
AiModel model = ((OpenAiModel)AiModel.Create(AiModelType.Gpt4OMini).WithApiKey(apiKey)).WithOrganization("Organization").WithProject("Project");

SummarizeOptions options = new SummarizeOptions();

options.SummaryLength = SummaryLength.Short;
Document oneDocumentSummary = model.Summarize(firstDoc, options);
oneDocumentSummary.Save("AI.AiSummarize.One.docx");

options.SummaryLength = SummaryLength.Long;
Document multiDocumentSummary = model.Summarize(new Document[] { firstDoc, secondDoc }, options);
multiDocumentSummary.Save("AI.AiSummarize.Multi.docx");
```

**Check Grammar Using AI**

Use one of the [CheckGrammar](https://reference.aspose.com/words/net/aspose.words.ai/aimodel/checkgrammar/) methods to correct spelling, fix grammatical errors and typos, improve stylistic quality, and optionally track changes using revisions for later review:

```csharp
Document doc = new Document("Big document.docx");

string apiKey = Environment.GetEnvironmentVariable("API_KEY");
// Use OpenAI generative language models.
AiModel model = AiModel.Create(AiModelType.Gpt4OMini).WithApiKey(apiKey);

CheckGrammarOptions grammarOptions = new CheckGrammarOptions();
grammarOptions.ImproveStylistics = true;

Document proofedDoc = model.CheckGrammar(doc, grammarOptions);
proofedDoc.Save("AI.AiGrammar.docx");
```

---