
# Aspose.Words for .NET - Document Protection

---

**URL:** https://docs.aspose.com/words/net/protect-or-encrypt-a-document.md

**Contents:**
- Document Protection Options
- Make a Document Read-Only
- Encrypt a Document
- Restrict Document Editing

---
title: "Protect or Encrypt a Document"
---

**Document Protection Options**

Aspose.Words currently provides the document features listed in the table below. You can find the details on each of the features in the corresponding child article in the current section.

| Aspose.Words protection feature | Corresponding child article    | Corresponding MS Word feature                                |
| ------------------------------- | ------------------------------ | ------------------------------------------------------------ |
| Read-Only                       | “Make a Document Read-Only”    | Always Open Read-Only (File → Info → Protect Document)<br />Alternative feature: "Password to modify" (Save As → Tools → General Options → Password) |
| Encrypt a Document              | “Encrypt a Document”           | Encrypt with Password (File → Info → Protect Document)<br />Alternative feature: "Password to open" (Save As → Tools → General Options → Password) |
| Restrict Editing                | “Restrict Document Editing”    | Restrict Editing (File – Info – Protect Document)<br />Alternative feature: "Restrict Editing" (Review → Protect → Restrict Editing) |
| Digital Signatures              | “Work with Digital Signatures” | Add a Digital Signature (File → Info → Protect Document)     |

**Make a Document Read-Only**

Aspose.Words allows you to make a document read-only to restrict editing by using the [ReadOnlyRecommended](https://reference.aspose.com/words/net/aspose.words.settings/writeprotection/readonlyrecommended/) property and the [SetPassword](https://reference.aspose.com/words/net/aspose.words.settings/writeprotection/setpassword/) method.

```csharp
Document doc = new Document();
DocumentBuilder builder = new DocumentBuilder(doc);

builder.Write("Open document as read-only");

// Enter a password that's up to 15 characters long.
doc.WriteProtection.SetPassword("MyPassword");

// Make the document as read-only.
doc.WriteProtection.ReadOnlyRecommended = true;

// Apply write protection as read-only.
doc.Protect(ProtectionType.ReadOnly);
doc.Save("DocumentProtection.ReadOnlyProtection.docx");
```
**Encrypt a Document**

To encrypt a document, use the **Password** property to provide a password that functions as an encryption key. This will modify the content of your document and make it unreadable. The encrypted document will require to have this password entered before it can be opened.

You can find the appropriate **Password** property for the required format. Each document save format in the [Saving Namespace](https://reference.aspose.com/words/net/aspose.words.saving/) has a corresponding class containing save options for this format. For example, the [Password](https://reference.aspose.com/words/net/aspose.words.saving/docsaveoptions/password/) property in the [DocSaveOptions](https://reference.aspose.com/words/net/aspose.words.saving/docsaveoptions/) class for DOC, or the [Password](https://reference.aspose.com/words/net/aspose.words.saving/ooxmlsaveoptions/password/) property in the [OoxmlSaveOptions](https://reference.aspose.com/words/net/aspose.words.saving/ooxmlsaveoptions/) class for DOCX, DOCM, DOTX, DOTM, and FlatOpc.

```csharp
Document doc = new Document();
DocumentBuilder builder = new DocumentBuilder(doc);
            
builder.Write("Hello world!");

DocSaveOptions saveOptions = new DocSaveOptions { Password = "password" };

doc.Save("WorkingWithDocSaveOptions.EncryptDocumentWithPassword.docx", saveOptions);
```

**Restrict Document Editing**

Aspose.Words allows you to control the way you restrict the content using the [ProtectionType](https://reference.aspose.com/words/net/aspose.words/protectiontype/) enumeration parameter. This will enable you to select an exact type of protection such as the following:

* AllowOnlyComments
* AllowOnlyFormFields
* AllowOnlyRevisions
* ReadOnly
* NoProtection

Aspose.Words allows you to protect your documents from changes using the [Protect](https://reference.aspose.com/words/net/aspose.words/document/protect/#protect/) method. This method is not a security feature and does not encrypt a document.

```csharp
Document doc = new Document();

// Apply document protection.
doc.Protect(ProtectionType.NoProtection, "password");

doc.Save("DocumentProtection.PasswordProtection.docx");
```

The following code example shows how to remove protection from your document:

```csharp
// For complete examples and data files, please go to https://github.com/aspose-words/Aspose.Words-for-.NET.git.
Document doc = new Document();
DocumentBuilder builder = new DocumentBuilder(doc);

builder.Writeln("Text added to a document.");

// Documents can have protection removed either with no password, or with the correct password.
doc.Unprotect();
doc.Protect(ProtectionType.ReadOnly, "newPassword");
doc.Unprotect("newPassword");

doc.Save("DocumentProtection.RemoveDocumentProtection.docx");
```

---