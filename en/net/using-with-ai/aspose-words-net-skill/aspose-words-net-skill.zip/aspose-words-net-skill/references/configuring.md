# Aspose.Words for .NET - Configuring

---

**URL:** https://docs.aspose.com/words/net/working-with-hyphenation.md

**Contents:**
- Hyphenation Dictionaries
- Loading Hyphenation Dictionaries

---
title: "Hyphenation"
---

Hyphenation is a way to arrange text in a document more compactly. However, it is important to remember that hyphenation rules may vary depending on the language.

To ensure correct word hyphenation, language-specific hyphenation dictionaries are used.

**Hyphenation Dictionaries**

Different languages use different norms and rules for word hyphenation.The optimal solution for correct hyphenation is to use special dictionaries. Aspose.Words uses OpenOffice dictionaries.

For spell checking, OpenOffice uses the [Hunspell library](https://hunspell.github.io/). Hunspell uses the [Hyphen](https://github.com/hunspell/hyphen) for hyphenation.

Hyphenation dictionaries can be taken from the [LibreOffice dictionaries GitHub](https://github.com/LibreOffice/dictionaries). For example, [en-US hyphenation dictionary](https://github.com/LibreOffice/dictionaries/blob/master/en/hyph_en_US.dic).

As Microsoft Word uses dictionaries other than OpenOffice dictionaries to perform hyphenation, sometimes we have to advise customers to add the necessary patterns to their dictionaries in order to fix the hyphenation of particular words.

**Loading Hyphenation Dictionaries**

To use the hyphenation feature, first register a hyphenation dictionary.

Load hyphenation dictionaries for the specified languages from a file:

```csharp
Document doc = new Document("German text.docx");

Hyphenation.RegisterDictionary("en-US", "hyph_en_US.dic");
Hyphenation.RegisterDictionary("de-CH", "hyph_de_CH.dic");

doc.Save("WorkingWithHyphenation.HyphenateWords.pdf");
```

Load hyphenation dictionaries for the specified language from a stream:

```csharp
Document doc = new Document("German text.docx");
            
Stream stream = File.OpenRead("hyph_de_CH.dic");
Hyphenation.RegisterDictionary("de-CH", stream);

doc.Save("WorkingWithHyphenation.LoadHyphenationDictionary.pdf");
```

Register only required hyphenation dictionaries “by request”. To achieve that, implement the [IHyphenationCallback](https://reference.aspose.com/words/net/aspose.words/ihyphenationcallback/) interface and use the static callback [Callback](https://reference.aspose.com/words/net/aspose.words/hyphenation/callback/):

```csharp
public void HyphenationCallback()
{
    try
    {
        // Register hyphenation callback.
        Hyphenation.Callback = new CustomHyphenationCallback();

        Document document = new Document("German text.docx");
        document.Save("WorkingWithHyphenation.HyphenationCallback.pdf");
    }
    catch (Exception e) when (e.Message.StartsWith("Missing hyphenation dictionary"))
    {
        Console.WriteLine(e.Message);
    }
    finally
    {
        Hyphenation.Callback = null;
    }
}

public class CustomHyphenationCallback : IHyphenationCallback
{
    public void RequestDictionary(string language)
    {
        string dictionaryFullFileName;
        switch (language)
        {
            case "en-US":
                dictionaryFullFileName = Path.Combine(dictionaryFolder, "hyph_en_US.dic");
                break;
            case "de-CH":
                dictionaryFullFileName = Path.Combine(dictionaryFolder, "hyph_de_CH.dic");
                break;
            default:
                throw new Exception($"Missing hyphenation dictionary for {language}.");
        }
        // Register dictionary for requested language.
        Hyphenation.RegisterDictionary(language, dictionaryFullFileName);
    }
}
```

---

**URL:** https://docs.aspose.com/words/net/working-with-asian-typography.md

**Contents:**
- Automatically Adjust Space between Asian and Latin Text or Numbers
- Set Line Break Options

---
title: "Asian Typography"
---

Asian Typography is a set of options for text paragraphs in documents written in Asian languages.

**Automatically Adjust Space between Asian and Latin Text or Numbers**

If you are designing a template with both East Asian and Latin text and  want to enhance the appearance of your form template by controlling the spaces between both types of text, you can configure your form template to automatically adjust the spaces between these two types of text. Use [AddSpaceBetweenFarEastAndAlpha](https://reference.aspose.com/words/net/aspose.words/paragraphformat/addspacebetweenfareastandalpha/) and [AddSpaceBetweenFarEastAndDigit](https://reference.aspose.com/words/net/aspose.words/paragraphformat/addspacebetweenfareastanddigit/) properties of the [ParagraphFormat](https://reference.aspose.com/words/net/aspose.words/paragraphformat/) class:

```csharp
Document doc = new Document();
DocumentBuilder builder = new DocumentBuilder(doc);

ParagraphFormat paragraphFormat = builder.ParagraphFormat;
paragraphFormat.AddSpaceBetweenFarEastAndAlpha = true;
paragraphFormat.AddSpaceBetweenFarEastAndDigit = true;

builder.Writeln("Automatically adjust space between Asian and Latin text");
builder.Writeln("Automatically adjust space between Asian text and numbers");

doc.Save("DocumentFormatting.SpaceBetweenAsianAndLatinText.docx");
```

**Set Line Break Options**

The Asian Typography tab of the paragraph properties dialog box in Microsoft Word has line break group. The options of this group can be set using the [FarEastLineBreakControl](https://reference.aspose.com/words/net/aspose.words/paragraphformat/fareastlinebreakcontrol/), [WordWrap](https://reference.aspose.com/words/net/aspose.words/paragraphformat/wordwrap/), [HangingPunctuation](https://reference.aspose.com/words/net/aspose.words/paragraphformat/hangingpunctuation/):

```csharp
Document doc = new Document("Asian typography.docx");

ParagraphFormat format = doc.FirstSection.Body.Paragraphs[0].ParagraphFormat;
format.FarEastLineBreakControl = false;
format.WordWrap = true;
format.HangingPunctuation = false;

doc.Save("DocumentFormatting.AsianTypographyLineBreakGroup.docx");
```

---