# Aspose.Words for .NET - Save a Document

---

**URL:** https://docs.aspose.com/words/net/save-a-document.md

**Contents:**
- Save to a File
- Save to a Stream
- Send a Document to a Client Browser

---
title: "Save a Document"
---

To save a document Aspose.Words provides the [Save](https://reference.aspose.com/words/net/aspose.words/document/save/) method. There are overloads that allow saving a document to a file, stream, or ASP.NET HttpResponse object for sending to a client browser. The document can be saved in any [save format](https://reference.aspose.com/words/net/aspose.words/saveformat/) supported by Aspose.Words.

**Save to a File**

Simply use the [Save](https://reference.aspose.com/words/net/aspose.words/document/save/) method with a file name. Aspose.Words will determine the save format from the file extension that you specify.

```csharp
Document doc = new Document("Document.doc");

doc.Save("BaseConversions.DocToDocx.docx");
```

**Save to a Stream**

Pass a stream object to the [Save](https://reference.aspose.com/words/net/aspose.words/document/save/) method. It's necessary to specify the save format explicitly when saving to a stream.

```csharp
Document doc;
using (Stream stream = File.OpenRead("Document.docx"))
    doc = new Document(stream);

// ... do something with the document.

// Convert the document to a different format and save to stream.
using (MemoryStream dstStream = new MemoryStream())
{
    doc.Save(dstStream, SaveFormat.Rtf);
    // Rewind the stream position back to zero so it is ready for the next reader.
    dstStream.Position = 0;

    File.WriteAllBytes("BaseConversions.DocxToRtf.rtf", dstStream.ToArray());
}
```

**Send a Document to a Client Browser**

In order to send a document to a client browser, use a special overload that takes four parameters: file name, save format, save type, and an ASP.NET HttpResponse object. The way the document will be presented to the user is represented by the [ContentDisposition](https://reference.aspose.com/words/net/aspose.words/contentdisposition/) enumeration, which determines whether the document sent to the browser will provide an option to open itself directly in the browser or in the application associated with the file extension.

```csharp
Document doc = new Document("Document.doc");

doc.Save("BaseConversions.DocToDocx.docx");
```

This overload of the `Save` method is not available when using the .NET Client Profile DLL. This DLL is located in the **net3.5_ClientProfile** folder. The .NET Client Profile excludes assemblies such as **System.Web**, therefore, **HttpResponse** is not available. This is entirely by design.

**Save to PCL**

Aspose.Words supports saving a document into PCL (Printer Command Language). Aspose.Words can save documents into PCL 6 (PCL 6 Enhanced or PCL XL) format. The `PclSaveOptions` class can be used to specify additional options when saving a document into the PCL format.

The following code example shows how to save a document to PCL using save options:

```csharp
Document doc = new Document("Rendering.docx");

PclSaveOptions saveOptions = new PclSaveOptions
{
    SaveFormat = SaveFormat.Pcl, RasterizeTransformedElements = false
};

doc.Save("WorkingWithPclSaveOptions.RasterizeTransformedElements.pcl", saveOptions);
```

---


**URL:** https://docs.aspose.com/words/net/specify-save-options.md

---
title: "Specify Save Options"
---

When saving a document, you can set some advanced properties. Aspose.Words provides you with the [SaveOptions](https://reference.aspose.com/words/net/aspose.words.saving/saveoptions/) class, which allows more precise control of the save process. There are overloads of the **Save** method that accept a **SaveOptions** object – it should be an object of a class derived from the **SaveOptions** class.

Each save format has a corresponding class that holds save options for this save format, for example, there is [PdfSaveOptions](https://reference.aspose.com/words/net/aspose.words.saving/pdfsaveoptions/) for saving to PDF format, [MarkdownSaveOptions](https://reference.aspose.com/words/net/aspose.words.saving/markdownsaveoptions/) for saving to Markdown format, or [ImageSaveOptions](https://reference.aspose.com/words/net/aspose.words.saving/imagesaveoptions/) for saving to an image. This article provides examples of working with some options classes derived from **SaveOptions**.

Set the save options before saving the document into HTML:

```csharp
Document doc = new Document("Rendering.docx");

string imagesDir = Path.Combine(ArtifactsDir, "Images");

// The folder specified needs to exist and should be empty.
if (Directory.Exists(imagesDir))
    Directory.Delete(imagesDir, true);

Directory.CreateDirectory(imagesDir);

// Set an option to export form fields as plain text, not as HTML input elements.
HtmlSaveOptions saveOptions = new HtmlSaveOptions(SaveFormat.Html)
{
    ExportTextInputFormFieldAsText = true, ImagesFolder = imagesDir
};

doc.Save("WorkingWithHtmlSaveOptions.ExportTextInputFormFieldAsText.html", saveOptions);
```

Set a password to encrypt a document using the RC4 encryption method:

```csharp
Document doc = new Document();
DocumentBuilder builder = new DocumentBuilder(doc);
            
builder.Write("Hello world!");

DocSaveOptions saveOptions = new DocSaveOptions { Password = "password" };

doc.Save("WorkingWithDocSaveOptions.EncryptDocumentWithPassword.docx", saveOptions);
```

Load and save OpenDocument encrypted with a password:

```csharp
Document doc = new Document("Encrypted.docx", new LoadOptions("docPassword"));

doc.Save("WorkingWithLoadOptions.LoadSaveEncryptedDocument.odt", new OdtSaveOptions("newPassword"));
```

Not all formats support encryption and the use of **Password** property.

Update the document creation time:

```csharp
Document doc = new Document("Rendering.docx");

PdfSaveOptions saveOptions = new PdfSaveOptions { UpdateLastPrintedProperty = true };

doc.Save("WorkingWithPdfSaveOptions.UpdateLastPrinted.pdf", saveOptions);
```

Save a black and white image with one bit per pixel format:

```csharp
Document doc = new Document("Rendering.docx");

ImageSaveOptions saveOptions = new ImageSaveOptions(SaveFormat.Png)
{
    PageSet = new PageSet(1),
    ImageColorMode = ImageColorMode.BlackAndWhite,
    PixelFormat = ImagePixelFormat.Format1bppIndexed
};

doc.Save("WorkingWithImageSaveOptions.Format1BppIndexed.Png", saveOptions);
```

---