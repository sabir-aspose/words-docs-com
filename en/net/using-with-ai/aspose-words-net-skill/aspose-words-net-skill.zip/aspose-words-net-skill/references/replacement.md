# Aspose.Words for .NET - Find and Replace

---

**URL:** https://docs.aspose.com/words/net/find-and-replace.md

**Contents:**
- Find and Replace Text Using Simple String Replacement
- Find and Replace Text Using Regular Expressions
- Find and Replace String Using Metacharacters
- Find and Replace String in Header/Footer of a Document
- Ignore Text During Find and Replace
- Customize Find and Replace Operation

---
title: "Find and Replace"
---

Aspose.Words allows you to find a specific string or regular expression pattern in your document and replace it with an alternative without installing and using additional applications such as Microsoft Word.

Aspose.Words presents the find and replace functionality with the [Aspose.Words.Replacing](https://reference.aspose.com/words/net/aspose.words.replacing/) namespace. You can work with many options during the find and replace process using [FindReplaceOptions](https://reference.aspose.com/words/net/aspose.words.replacing/findreplaceoptions/) class.

You can use one of the [Replace](https://reference.aspose.com/words/net/aspose.words/range/replace/#replace/) methods to find or replace in various scenarios.

**Find and Replace Text Using Simple String Replacement**

In this case, you can specify a string to be replaced, a string that will replace all its occurrences, whether the replacement is case-sensitive, and whether only stand-alone words will be affected.

The following code example shows how to find the string “_CustomerName_” and replace it with the string *“James Bond”*:

```csharp
Document doc = new Document();
DocumentBuilder builder = new DocumentBuilder(doc);
            
builder.Writeln("Hello _CustomerName_,");

doc.Range.Replace("_CustomerName_", "James Bond", new FindReplaceOptions(FindReplaceDirection.Forward));

doc.Save("FindAndReplace.ReplaceWithString.docx");
```

**Find and Replace Text Using Regular Expressions**

A regular expression (regex) is a pattern that describes a certain sequence of text. Suppose you want to replace all double occurrences of a word with a single word occurrence. Then you can apply the following regular expression to specify the double-word pattern: `([a-zA-Z]+) \1`.

The following code example shows how to replace strings that match a regular expression pattern with a specified replacement string:

```csharp
Document doc = new Document();
DocumentBuilder builder = new DocumentBuilder(doc);
            
builder.Writeln("sad mad bad");

FindReplaceOptions options = new FindReplaceOptions();

doc.Range.Replace(new Regex("[s|m]ad"), "bad", options);

doc.Save("FindAndReplace.ReplaceWithRegex.docx");
```

**Find and Replace String Using Metacharacters**

You can use metacharacters in the search string or the replacement string if a particular text or phrase is composed of multiple paragraphs, sections, or pages. Some of the metacharacters include **&p** for a paragraph break, **&b** for a section break, **&m** for a page break, and **&l** for a line break.

Note that the metacharacter **&&** equals to **&**. For example, if you need to find text for **&p** that is not a paragraph break, then you can use **&&p**.

The following code example shows how to replace text with paragraph and page break:

```csharp
Document doc = new Document();
DocumentBuilder builder = new DocumentBuilder(doc);

builder.Font.Name = "Arial";
builder.Writeln("First section");
builder.Writeln("  1st paragraph");
builder.Writeln("  2nd paragraph");
builder.Writeln("{insert-section}");
builder.Writeln("Second section");
builder.Writeln("  1st paragraph");

FindReplaceOptions findReplaceOptions = new FindReplaceOptions();
findReplaceOptions.ApplyParagraphFormat.Alignment = ParagraphAlignment.Center;

// Double each paragraph break after word "section", add kind of underline and make it centered.
int count = doc.Range.Replace("section&p", "section&p----------------------&p", findReplaceOptions);

// Insert section break instead of custom text tag.
count = doc.Range.Replace("{insert-section}", "&b", findReplaceOptions);

doc.Save("FindAndReplace.ReplaceTextContainingMetaCharacters.docx");
```

**Find and Replace String in Header/Footer of a Document**

You can find and replace text in the header/footer section of a Word document using the [HeaderFooter](https://reference.aspose.com/words/net/aspose.words/headerfooter/) class:

```csharp
Document doc = new Document("Footer.docx");

HeaderFooterCollection headersFooters = doc.FirstSection.HeadersFooters;
HeaderFooter footer = headersFooters[HeaderFooterType.FooterPrimary];

FindReplaceOptions options = new FindReplaceOptions { MatchCase = false, FindWholeWordsOnly = false };
footer.Range.Replace("(C) 2006 Aspose Pty Ltd.", "Copyright (C) 2020 by Aspose Pty Ltd.", options);

doc.Save("FindAndReplace.ReplaceTextInFooter.docx");
```

**Ignore Text During Find and Replace**

While applying the find and replace operation, you can ignore certain segments of the text. So, certain parts of the text can be excluded from the search, and the find and replace can be applied only to the remaining parts.

Aspose.Words provides many find and replace properties for ignoring text such as [IgnoreDeleted](https://reference.aspose.com/words/net/aspose.words.replacing/findreplaceoptions/ignoredeleted/), [IgnoreFieldCodes](https://reference.aspose.com/words/net/aspose.words.replacing/findreplaceoptions/ignorefieldcodes/), [IgnoreFields](https://reference.aspose.com/words/net/aspose.words.replacing/findreplaceoptions/ignorefields/), [IgnoreFootnotes](https://reference.aspose.com/words/net/aspose.words.replacing/findreplaceoptions/ignorefootnotes/), and [IgnoreInserted](https://reference.aspose.com/words/net/aspose.words.replacing/findreplaceoptions/ignoreinserted/).

The following code example shows how to ignore text inside delete revisions:

```csharp
Document doc = new Document();
DocumentBuilder builder = new DocumentBuilder(doc);

// Insert non-revised text.
builder.Writeln("Deleted");
builder.Write("Text");

// Remove first paragraph with tracking revisions.
doc.StartTrackRevisions("author", DateTime.Now);
doc.FirstSection.Body.FirstParagraph.Remove();
doc.StopTrackRevisions();

FindReplaceOptions options = new FindReplaceOptions { IgnoreDeleted = true };

Regex regex = new Regex("e");
doc.Range.Replace(regex, "*", options);

Console.WriteLine(doc.GetText());

options.IgnoreDeleted = false;
doc.Range.Replace(regex, "*", options);

Console.WriteLine(doc.GetText());
```

**Customize Find and Replace Operation**

Aspose.Words provides many different [properties](https://reference.aspose.com/words/net/aspose.words.replacing/findreplaceoptions/) to find and replace text such as applying specific format with [ApplyFont](https://reference.aspose.com/words/net/aspose.words.replacing/findreplaceoptions/applyfont/) and [ApplyParagraphFormats](https://reference.aspose.com/words/net/aspose.words.replacing/findreplaceoptions/applyparagraphformat/) properties, using substitutions in replacement patterns with [UseSubstitutions](https://reference.aspose.com/words/net/aspose.words.replacing/findreplaceoptions/usesubstitutions/) property, and others.

The following code example shows how to highlight a specific word in your document:

```csharp
Document doc = new Document("Footer.docx");

FindReplaceOptions options = new FindReplaceOptions();
options.ApplyFont.HighlightColor = Color.DarkOrange;
doc.Range.Replace(new Regex("(header|footer)"), "", options);
```

Aspose.Words allows you to use the [IReplacingCallback](https://reference.aspose.com/words/net/aspose.words.replacing/ireplacingcallback/) interface to create and call a custom method during a replace operation.

If you need to replace a string with an HTML tag, apply the **IReplacingCallback** interface to customize the find and replace operation so the match starts at the beginning of a run with the match node of your document. Let us provide several examples of using **IReplacingCallback**.

The following code example shows how to replace text specified with HTML:

```csharp
public void ReplaceWithHtml()
{
    Document doc = new Document();
    DocumentBuilder builder = new DocumentBuilder(doc);

    builder.Writeln("Hello <CustomerName>,");

    FindReplaceOptions options = new FindReplaceOptions();
    options.ReplacingCallback = new ReplaceWithHtmlEvaluator(options);

    doc.Range.Replace(new Regex(@" <CustomerName>,"), string.Empty, options);

    doc.Save("FindAndReplace.ReplaceWithHtml.docx");
}

private class ReplaceWithHtmlEvaluator : IReplacingCallback
{
    internal ReplaceWithHtmlEvaluator(FindReplaceOptions options)
    {
        mOptions = options;
    }

    /// <summary>
    /// NOTE: This is a simplistic method that will only work well when the match
    /// starts at the beginning of a run.
    /// </summary>
    ReplaceAction IReplacingCallback.Replacing(ReplacingArgs args)
    {
        DocumentBuilder builder = new DocumentBuilder((Document) args.MatchNode.Document);
        builder.MoveTo(args.MatchNode);

        // Replace '<CustomerName>' text with a red bold name.
        builder.InsertHtml("<b><font color='red'>James Bond, </font></b>");
        args.Replacement = "";

        return ReplaceAction.Replace;
    }

    private readonly FindReplaceOptions mOptions;
}
```

The following code example shows how to prepend a line number to each line:

```csharp
public void LineCounter()
{
    Document doc = new Document();
    DocumentBuilder builder = new DocumentBuilder(doc);

    builder.Writeln("This is first line");
    builder.Writeln("Second line");
    builder.Writeln("And last line");

    // Prepend each line with line number.
    FindReplaceOptions opt = new FindReplaceOptions() { ReplacingCallback = new LineCounterCallback() };
    doc.Range.Replace(new Regex("[^&p]*&p"), "", opt);

    doc.Save("FindAndReplace.LineCounter.docx");
}

internal class LineCounterCallback : IReplacingCallback
{
    public ReplaceAction Replacing(ReplacingArgs args)
    {
        Debug.WriteLine(args.Match.Value);

        args.Replacement = string.Format("{0} {1}", mCounter++, args.Match.Value);
        return ReplaceAction.Replace;
    }

    private int mCounter = 1;
}
```

---