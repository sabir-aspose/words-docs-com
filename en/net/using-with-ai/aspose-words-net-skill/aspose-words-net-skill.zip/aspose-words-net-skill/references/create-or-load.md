# Aspose.Words for .NET - Create or Load a Document

---

**URL:** https://docs.aspose.com/words/net/create-or-load-a-document.md

**Contents:**
- Create a New Document
- Load from a File
- Load from a Stream

---
title: "Create or Load a Document"
---

The [Document](https://reference.aspose.com/words/net/aspose.words/document/) class represents a document loaded into memory. The document has several overloaded constructors allowing you to create a blank document or to load it from a file or stream. The document can be loaded in any [LoadFormat](https://reference.aspose.com/words/net/aspose.words/loadformat/) supported by Aspose.Words.

**Create a New Document**

To create a new blank document call the [Document](https://reference.aspose.com/words/net/aspose.words/document/document/) constructor without parameters. To generate a document programmatically, use the [DocumentBuilder](https://reference.aspose.com/words/net/aspose.words/documentbuilder/) class to add document contents.

```csharp
Document doc = new Document();

// Use a document builder to add content to the document.
DocumentBuilder builder = new DocumentBuilder(doc);
builder.Writeln("Hello World!");

doc.Save("AddContentUsingDocumentBuilder.CreateNewDocument.docx");
```

Default values:

- A blank document contains one section with default parameters, one empty paragraph, some document styles. Actually this document is the same as the result of creating the “New document” in Microsoft Word.
- The document paper size is [PaperSize](https://reference.aspose.com/words/net/aspose.words/papersize/).**Letter**.

**Load from a File**

Pass a file name as string to the Document constructor to open an existing document from a file.

```csharp
Document doc = new Document("Document.docx");
```

**Load from a Stream**

To open a document from a stream, simply pass a stream object that contains the document into the Document constructor.

```csharp
Document doc;
using (Stream stream = File.OpenRead("Document.docx"))
    doc = new Document(stream);
```

---


**URL:** https://docs.aspose.com/words/net/specify-load-options.md

**Contents:**
- Set Microsoft Word Version
- Set Language Preferences
- Use WarningCallback to Control Problems While Loading a Document
- Use ResourceLoadingCallback to Control the External Resources Loading
- Use TempFolder to Avoid a Memory Exception
- Set the Encoding Explicitly
- Load Encrypted Documents

---
title: "Specify Load Options"
---

When loading a document, you can set some advanced properties with the [LoadOptions](https://reference.aspose.com/words/net/aspose.words.loading/loadoptions/) class. Some load formats have a corresponding class that holds load options for this load format, for example, there is [PdfLoadOptions](https://reference.aspose.com/words/net/aspose.words.loading/pdfloadoptions/) for loading to PDF format or [TxtLoadOptions](https://reference.aspose.com/words/net/aspose.words.loading/txtloadoptions/) for loading to TXT.

**Set Microsoft Word Version**

Different versions of Microsoft Word application can display documents in differently. Essential document markup elements may be missing or may be interpreted differently causing Microsoft Word 2019 to show such a document differently compared to Microsoft Word 2010.

By default Aspose.Words opens documents using Microsoft Word 2019 rules. You can explicitly specify the desired version using the [MswVersion](https://reference.aspose.com/words/net/aspose.words.loading/loadoptions/mswversion/) property:

```csharp
LoadOptions loadOptions = new LoadOptions { MswVersion = MsWordVersion.Word2010 };
            
Document doc = new Document("Document.docx", loadOptions);

doc.Save("WorkingWithLoadOptions.SetMsWordVersion.docx");
```

**Set Language Preferences**

Microsoft Word may show documents differently depending on the "Office Language Preferences" dialog settings, that can be found in "File → Options → Languаge". Aspose.Words provides the [LanguagePreferences](https://reference.aspose.com/words/net/aspose.words.loading/languagepreferences/) property as the equivalent of this dialog. If Aspose.Words output differs from the Microsoft Word output, set the appropriate value for **EditingLanguage** – this can improve the output document:

```csharp
LoadOptions loadOptions = new LoadOptions();
// Set language preferences that will be used when document is loading.
loadOptions.LanguagePreferences.AddEditingLanguage(EditingLanguage.Japanese);
            
Document doc = new Document("No default editing language.docx", loadOptions);
```

**Use WarningCallback to Control Problems While Loading a Document**

 If you want to know about problems that occurred while loading a document, Aspose.Words provides the [IWarningCallback](https://reference.aspose.com/words/net/aspose.words/iwarningcallback/) interface.

```csharp
public class DocumentLoadingWarningCallback : IWarningCallback
{
    public void Warning(WarningInfo info)
    {
        // Prints warnings and their details as they arise during document loading.
        Console.WriteLine($"WARNING: {info.WarningType}, source: {info.Source}");
        Console.WriteLine($"\tDescription: {info.Description}");
    }
}
```

To get information about all problems throughout the load time, use the [WarningCallback](https://reference.aspose.com/words/net/aspose.words.loading/loadoptions/warningcallback/) property.

```csharp
LoadOptions loadOptions = new LoadOptions { WarningCallback = new DocumentLoadingWarningCallback() };
            
Document doc = new Document("Document.docx", loadOptions);
```

**Use ResourceLoadingCallback to Control the External Resources Loading**

A document may contain external links to images located somewhere on a local disk, network, or Internet. Aspose.Words automatically loads such images into a document, but there are situations when this process needs to be controlled. The [ResourceLoadingCallback](https://reference.aspose.com/words/net/aspose.words.loading/loadoptions/resourceloadingcallback/) load option allows you to control this.

Implementthe [IResourceLoadingCallback](https://reference.aspose.com/words/net/aspose.words.loading/iresourceloadingcallback/) interface:

```csharp
private class HtmlLinkedResourceLoadingCallback : IResourceLoadingCallback
{
    public ResourceLoadingAction ResourceLoading(ResourceLoadingArgs args)
    {
        switch (args.ResourceType)
        {
            case ResourceType.CssStyleSheet:
            {
                Console.WriteLine($"External CSS Stylesheet found upon loading: {args.OriginalUri}");
 
                // CSS file will don't used in the document.
                return ResourceLoadingAction.Skip;
            }
            case ResourceType.Image:
            {
                // Replaces all images with a substitute.
                Image newImage = Image.FromFile(ImagesDir + "Logo.jpg");
                
                ImageConverter converter = new ImageConverter();
                byte[] imageBytes = (byte[])converter.ConvertTo(newImage, typeof(byte[]));

                args.SetData(imageBytes);
 
                // New images will be used instead of presented in the document.
                return ResourceLoadingAction.UserProvided;
            }
            case ResourceType.Document:
            {
                Console.WriteLine($"External document found upon loading: {args.OriginalUri}");
 
                // Will be used as usual.
                return ResourceLoadingAction.Default;
            }
            default:
                throw new InvalidOperationException("Unexpected ResourceType value.");
        }
    }
}
```

Use the **ResourceLoadingCallback** property:

```csharp
LoadOptions loadOptions = new LoadOptions { ResourceLoadingCallback = new HtmlLinkedResourceLoadingCallback() };

// When we open an Html document, external resources such as references to CSS stylesheet files
// and external images will be handled customarily by the loading callback as the document is loaded.
Document doc = new Document("Images.html", loadOptions);

doc.Save("WorkingWithLoadOptions.ResourceLoadingCallback.pdf");
```

**Use TempFolder to Avoid a Memory Exception**

Aspose.Words supports extremely large documents that have thousands of pages full of rich content. If you have a problem with Out of Memory exception while loading a document, try to use the [TempFolder](https://reference.aspose.com/words/net/aspose.words.loading/loadoptions/tempfolder/) property:

```csharp
LoadOptions loadOptions = new LoadOptions { TempFolder = ArtifactsDir };

Document doc = new Document("Document.docx", loadOptions);
```

**Set the Encoding Explicitly**

Aspose.Words tries to automatically detect the appropriate encoding by default, but in a rare case you may need to use an encoding different from the one detected by our encoding recognition algorithm. Use the [Encoding](https://reference.aspose.com/words/net/aspose.words.loading/loadoptions/encoding/) property to get or set the encoding:

```csharp
LoadOptions loadOptions = new LoadOptions { Encoding = Encoding.ASCII };

// Load the document while passing the LoadOptions object, then verify the document's contents.
Document doc = new Document("English text.txt", loadOptions);
```

**Load Encrypted Documents**

You can load Word documents encrypted with a password. Use a special constructor overload, which accepts a [LoadOptions](https://reference.aspose.com/words/net/aspose.words.loading/loadoptions/) object. This object contains the [Password](https://reference.aspose.com/words/net/aspose.words.loading/loadoptions/password/) property, which specifies the password string:

```csharp
Document doc = new Document("Encrypted.docx", new LoadOptions("docPassword"));
```

If you do not know in advance whether the file is encrypted, you can use the [FileFormatUtil](https://reference.aspose.com/words/net/aspose.words/fileformatutil/) class and the [IsEncrypted](https://reference.aspose.com/words/net/aspose.words/fileformatinfo/isencrypted/) property:

```csharp
FileFormatInfo info = FileFormatUtil.DetectFileFormat("Encrypted.docx");
Console.WriteLine(info.IsEncrypted);
```

---