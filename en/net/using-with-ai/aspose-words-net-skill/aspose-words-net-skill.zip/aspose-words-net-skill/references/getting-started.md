# Aspose.Words for .NET - Getting started

---

**URL:** https://docs.aspose.com/words/net/system-requirements.md

**Contents:**
- Supported Operating Systems
- Supported Cloud Platforms
- Supported Implementations

---
title: "System Requirements"
---

**Supported Operating Systems**

Aspose.Words for .NET is compatible with the following operating systems:

* Windows:
    * Windows 2003 Server (x64, x86)
    * Windows 2008 Server (x64, x86)
    * Windows 2012 Server (x64, x86)
    * Windows 2012 R2 Server (x64, x86)
    * Windows 2016 Server (x64, x86)
    * Windows 2019 Server (x64, x86)
    * Windows XP (x64, x86)
    * Windows Vista (x64, x86)
    * Windows 7 (x64, x86)
    * Windows 8, 8.1 (x64, x86)
    * Windows 10 (x64, x86)
    * Windows 11 (x64, x86)
* Linux (any modern distribution supporting .NET)
* macOS version 10.9 (Mavericks) and later

**Supported Cloud Platforms**

Aspose.Words for .NET also supports cloud platforms, including but not limited to:

* Amazon Web Services
* Microsoft Azure

**Supported Implementations**

Aspose.Words for .NET supports .NET and Mono frameworks:

* .NET Framework 3.5
* .NET Framework 4.0
* .NET Framework 4.0_ClientProfile
* .NET Framework 4.5.0
* .NET Framework 4.5.1
* .NET Framework 4.5.2
* .NET Framework 4.6.0
* .NET Framework 4.6.2
* .NET Framework 4.7
* .NET Framework 4.7.2
* .NET Framework 4.8
* Mono 2.6.7 and later

Aspose.Words for .NET also supports .NET Standard 2.0 specification and its implementations:

* .NET Standard 2.0:
    * .NET Core 2.0
    * .NET Core 2.1
    * .NET Core 2.2
    * .NET Core 3.0
    * .NET Core 3.1
    * .NET 5.0
    * .NET 6.0
    * .NET 7.0
    * .NET 8.0
    * .NET 9.0
    * .NET 10.0

---

**URL:** https://docs.aspose.com/words/net/installation.md

**Contents:**
- Installing via NuGet Package Manager
- Installing via Installer

---
title: "Installation"
---

**Installing via NuGet Package Manager**

Install Aspose.Words for .NET via NuGet:

```csharp
dotnet add package Aspose.Words
```
**Installing via Installer**

Or install Aspose.Words for .NET using Installer:

1. Download Aspose.Words_{LatestVersion}.msi from the [Download](https://releases.aspose.com/words/net/)
2. Run the installer and follow the on-screen instructions
3. Open your project in Visual Studio and add a reference to the installed Aspose.Words assembly

---