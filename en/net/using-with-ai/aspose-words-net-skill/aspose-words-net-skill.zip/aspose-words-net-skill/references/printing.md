# Aspose.Words for .NET - Print a Document

---

**URL:** https://docs.aspose.com/words/net/print-a-document-programmatically-or-using-dialogs.md

**Contents:**
- Printing a Document on a Server via the `XpsPrint` API
- Printing a Document with Settings and Print Preview Dialogs
- Hiding the Print Progress Dialog When Printing a Document

---
title: "Printing a Document Programmatically or Using Dialogs"
---

**Printing a Document on a Server via the `XpsPrint` API**

This section is intended for users who want to submit an XPS document to the unmanaged XpsPrint API from a .NET application using Aspose.Words.

**Methods to Print a Document on a Server**

The proper way to print documents according to Microsoft is by using the unmanaged XpsPrint API. This API is available on Windows 7, Windows Server 2008 R2, and on Windows Vista provided the Platform Update for Windows Vista is installed.

Since Aspose.Words can easily convert any document to XPS, you only need to write the code that passes an XPS document to the `XpsPrint` API. The only problem is that the `XpsPrint` API is unmanaged and requires some knowledge of the Platform Invoke technology.

To print a document, Aspose.Words provides an **XpsPrintHelper** class contains a simple Print method, where you just need to specify the following parameters (see more details in the article [Print Document via XPS API](/words/net/missing-features-in-openxml/)):

- Document you want to print.
- Printer name.
- Job name (optional).
- Boolean value, specifying whether the program should wait until the print job is completed. Therefore, the system will either check whether the document was printed successfully or return immediately after sending the print job. In the last case, it is impossible to identify whether the print job was successful.

Upon encountering any problems submitting or printing the document, the method will throw an exception.

The code example below shows how to print a document using the **XpsPrintHelper** class:

```csharp
string dataDir = RunExamples.GetDataDir_RenderingAndPrinting();
// Open a sample document in Aspose.Words.
Document document = new Document("TestFile.doc");

// Specify the name of the printer you want to print to.
const string printerName = @"\\COMPANY\Brother MFC-885CW Printer";

// Print the document.
XpsPrintHelper.Print(document, printerName, "My Test Job", true);
```

There are two overloads of the **XpsPrintHelper**.**Print** method. The first overload takes a [Document](https://reference.aspose.com/words/net/aspose.words/document/) object and saves it into a `MemoryStream` in the XPS format. The second overload accepts a `Stream` object. The stream must contain a document in the XPS format.

**Printing a Document with Settings and Print Preview Dialogs**

The Aspose.Words has no built-in dialogs or forms but implements the [AsposeWordsPrintDocument](https://reference.aspose.com/words/net/aspose.words.rendering/asposewordsprintdocument/) class, based on the .NET **PrintDocument** class. An instance of this class can be passed to the **PrintPreviewDialog** form to preview and print the document. Also, the [PrintPreviewDialog](https://docs.microsoft.com/en-us/dotnet/api/system.windows.forms.printpreviewdialog?view=netframework-4.8) class defines the output to transmit to a printer.

```csharp
string dataDir = RunExamples.GetDataDir_RenderingAndPrinting();
Document doc = new Document("TestFile.doc");

PrintDialog printDlg = new PrintDialog();

// Initialize the print dialog with the number of pages in the document.
printDlg.AllowSomePages = true;
printDlg.PrinterSettings.MinimumPage = 1;
printDlg.PrinterSettings.MaximumPage = doc.PageCount;
printDlg.PrinterSettings.FromPage = 1;
printDlg.PrinterSettings.ToPage = doc.PageCount;

// Сheck if the user accepted the print settings and whether to proceed to document preview.
if (printDlg.ShowDialog() != DialogResult.OK)
    return;

// Create a special Aspose.Words implementation of the .NET PrintDocument class.
// Pass the printer settings from the print dialog to the print document.
AsposeWordsPrintDocument awPrintDoc = new AsposeWordsPrintDocument(doc);
awPrintDoc.PrinterSettings = printDlg.PrinterSettings;

// Initialize the print preview dialog.
PrintPreviewDialog previewDlg = new PrintPreviewDialog();

// Pass the Aspose.Words print document to the print preview dialog.
previewDlg.Document = awPrintDoc;

// Specify additional parameters of the print preview dialog.
previewDlg.ShowInTaskbar = true;
previewDlg.MinimizeBox = true;
previewDlg.PrintPreviewControl.Zoom = 1;
previewDlg.Document.DocumentName = doc.OriginalFileName;
previewDlg.WindowState = FormWindowState.Maximized;

// Occur whenever the print preview dialog is first displayed.
previewDlg.Shown += PreviewDlg_Shown;

// Show the appropriately configured print preview dialog.
previewDlg.ShowDialog();
```

```csharp
private static void PreviewDlg_Shown(object sender, EventArgs e)
{
    // Bring the print preview dialog on top when it is initially displayed.
    ((PrintPreviewDialog)sender).Activate();
}
```

**Hiding the Print Progress Dialog When Printing a Document**

The Printing Progress Dialog does not appear when printing a document via the [Print](https://reference.aspose.com/words/net/aspose.words/document/print/) method. However, this dialog appears during printing with another [Print](https://reference.aspose.com/words/net/aspose.words.rendering/asposewordsprintdocument/) method. In this case, to prevent the Printing dialog from appearing, you should specify valid printer settings and a standard print controller in this method, as shown in the example below:

```csharp
string dataDir = RunExamples.GetDataDir_RenderingAndPrinting(); 
// Load the documents which store the shapes we want to render.
Document doc = new Document("TestFile RenderShape.doc");
// Obtain the settings of the default printer
System.Drawing.Printing.PrinterSettings settings = new System.Drawing.Printing.PrinterSettings();

// The standard print controller comes with no UI
System.Drawing.Printing.PrintController standardPrintController = new System.Drawing.Printing.StandardPrintController();

// Print the document using the custom print controller
AsposeWordsPrintDocument prntDoc = new AsposeWordsPrintDocument(doc);
prntDoc.PrinterSettings = settings;
prntDoc.PrintController = standardPrintController;
prntDoc.Print();
```

---